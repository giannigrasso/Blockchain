package ch.samt.blockchain.piccions.compiler;

public class CompileException extends Exception {
    
    public CompileException(String message) {
        super(message);
    }

}
