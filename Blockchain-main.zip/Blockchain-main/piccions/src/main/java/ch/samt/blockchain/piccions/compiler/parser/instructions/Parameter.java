package ch.samt.blockchain.piccions.compiler.parser.instructions;

public record Parameter(String name, String type, int size) {

}