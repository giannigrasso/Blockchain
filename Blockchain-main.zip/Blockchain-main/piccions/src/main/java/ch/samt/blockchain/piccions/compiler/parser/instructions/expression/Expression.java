package ch.samt.blockchain.piccions.compiler.parser.instructions.expression;

import ch.samt.blockchain.piccions.compiler.parser.instructions.Pushable;

public abstract class Expression implements Pushable {
    
}
