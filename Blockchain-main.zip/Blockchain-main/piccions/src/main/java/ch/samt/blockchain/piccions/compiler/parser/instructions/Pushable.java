package ch.samt.blockchain.piccions.compiler.parser.instructions;

public interface Pushable extends Compilable {
    
}
