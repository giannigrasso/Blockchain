package ch.samt.blockchain.common.protocol;

public class BadPacketException extends Exception {
    
    public BadPacketException(String message) {
        super(message);
    }

}
