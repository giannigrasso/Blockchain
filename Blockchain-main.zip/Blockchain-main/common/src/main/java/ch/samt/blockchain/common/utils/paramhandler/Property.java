package ch.samt.blockchain.common.utils.paramhandler;

public record Property(String property, String value) {

}