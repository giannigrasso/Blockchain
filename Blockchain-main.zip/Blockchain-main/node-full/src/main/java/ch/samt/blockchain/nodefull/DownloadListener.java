package ch.samt.blockchain.nodefull;

public interface DownloadListener {
    
    void onDownloadStart();

    void onDownloadEnd();

}
