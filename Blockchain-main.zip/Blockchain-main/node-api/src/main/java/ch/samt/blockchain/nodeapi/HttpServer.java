package ch.samt.blockchain.nodeapi;

public interface HttpServer {
    
    void terminate();

    void init();

}
