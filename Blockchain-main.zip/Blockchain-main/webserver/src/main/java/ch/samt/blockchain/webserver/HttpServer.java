package ch.samt.blockchain.webserver;

public interface HttpServer {
    
    void terminate();

    void init();

}
